﻿# Tushare 数据导入工具

将 Tushare Pro API 数据导入 DolphinDB 分布式数据库。本工具运行在 DolphinDB Web 平台，使用 `.dos` 脚本完成环境初始化、库表创建、API 拉取和数据写入。

## 快速开始

1. 先运行 `dolphindb-tushare-check-env` skill，确保 `httpClient` 插件和本次所选数据域所需的 `easy_tushare` 模块可用。
2. 准备 Tushare Pro token。
3. 选择一个或多个数据域：`stock`、`index`、`fund`、`bond`、`futures`、`options`、`etf`、`spot`、`fx`、`llm`。
4. 选择日期范围和每个数据域的表名。
5. 在 DolphinDB Web 中执行 `scripts/import_data.dos`。
6. 如需每日增量定时任务，确认历史任务完成后执行 `scripts/schedule_data.dos`。

## 参数说明

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| `token` | Tushare Pro API token | `xxxxxxxx` |
| `dataDomains` | 数据域数组 | `["stock", "index"]` |
| `startDate` | 导入起始日期，DolphinDB `DATE` | `2026.01.01` |
| `endDate` | 导入结束日期，DolphinDB `DATE` | `2026.01.02` |
| `tableNamesByDomain` | 按数据域指定表名，空映射表示全部 | `tableNamesByDomain["stock"] = ["stock_basic"]` |

## 文件结构

```text
├── README.md
├── SKILL.md
└── scripts/
    ├── import_data.dos
    ├── schedule_data.dos
    ├── machine_info_collection.dos
    └── DolphinDBModules/
        └── easy_tushare/
```

## 进度查询

导入函数内部会使用 `submitJob` 提交后台任务。任务提交后，可通过 `getRecentJobs()` 查看任务状态，并用 `loadTable(dbName, tableName)` 校验目标表行数。

## 多资产示例

```dos
dataDomains = ["stock", "index"]
tableNamesByDomain = dict(STRING, ANY)
tableNamesByDomain["stock"] = ["stock_basic", "daily"]
tableNamesByDomain["index"] = ["index_basic", "index_daily"]
```


