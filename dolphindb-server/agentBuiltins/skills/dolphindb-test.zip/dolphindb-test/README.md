# DolphinDB Test Skill

## 使用方式
1、在vs code中安装GitHub Copilot Chat扩展  
2、将dolphindb_test文件夹复制到~/.copilot/skills/下面  
3、在Chat对话框中输入/dolphindb_test启用skill
