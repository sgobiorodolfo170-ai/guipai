# DolphinDB Orca DStream API Coding Agent Skill

本 skill 用于辅助 coding agent 编写、审查和修复 **DolphinDB Orca 声明式 DStream API** 代码。它面向的核心场景是：用户给出一个实时流计算需求，coding agent 需要生成一份**完整、可运行、可复现、可验证**的 DolphinDB `.dos` 脚本。

## 1. 适用场景

当用户提出以下需求时，适合触发本 skill：

- 编写 Orca 声明式 DStream API 示例脚本
- 根据业务需求生成 Orca 流图代码
- 使用 `source`、`map`、`fork`、`buffer`、`sink` 搭建流计算链路
- 使用 `timeSeriesEngine`、`reactiveStateEngine`、`lookupJoinEngine`、`asofJoinEngine`、`crossSectionalEngine`、`sessionWindowEngine`、`ruleEngine`、`timerEngine` 等 Orca DStream 组件
- 审查 coding agent 生成的 Orca 代码是否能运行
- 修复 Orca DStream API 脚本中的常见问题
- 为 DolphinDB Orca 编写完整 mock 数据和结果查询脚本

## 2. 核心目标

本 skill 的目标不是只生成代码片段，而是要求 coding agent 默认输出完整脚本。完整脚本应包含：

1. 创建或切换 catalog
2. 清理旧流图，避免重复运行污染
3. 创建 `createStreamGraph`
4. 定义 source schema
5. 定义 DStream API 链式流图
6. 提交 `submit()`
7. 等待或检查流图状态
8. 构造 mock 数据
9. 使用 `appendOrcaStreamTable` 写入数据
10. 查询输入表、中间表和结果表
11. 说明调试环境与生产环境的清理差异

## 3. 核心原则

- 用户要求写 Orca / DStream API / 声明式流图时，必须使用 Orca DStream API，不能用普通 SQL 批计算替代。
- 默认输出完整可运行脚本，不输出伪代码，不只输出核心片段。
- 不凭记忆编造 DolphinDB / Orca API、参数名或配置项。
- 官方 Orca 文档只能作为 API 和结构参考；除非用户明确要求复现官方示例，否则不要照搬官方业务代码。
- 调试脚本必须考虑重复运行，避免旧流图、旧流表、旧 schema 或旧状态导致结果叠加。
- mock 数据必须能触发预期输出，尤其是告警类脚本不能只依赖随机数据。

## 4. 目录建议

建议 skill 包采用如下结构：

```text
.
├── SKILL.md
├── README.md
├── CATALOG.md
├── examples/
│   ├── trade_anomaly_monitor.dos
│   ├── net_buy_amount_monitor.dos
│   ├── price_deviation_ma5_alert.dos
│   ├── order_trade_slippage_monitor.dos
│   ├── trade_aggressiveness_monitor.dos
│   ├── industry_amount_rank.dos
│   ├── abnormal_spread_alert.dos
│   └── market_overview_timer.dos
└── references/
    └── orca/
        ├── rules_workflow.md
        ├── rules_codegen.md
        ├── rules_engines.md
        ├── rules_full_legacy.md
        ├── orca.md
        ├── orca_finance.md
        ├── orca_finance_position.md
        ├── orca_conversion_cases.md
        └── coding_agent_orca_issues.md
```

## 5. 参考资料

建议放入 `references/orca/` 目录的资料包括：

- `orca.md`：Orca 实时计算平台主文档
- `orca_finance.md`：Orca 金融案例文档
- `orca_finance_position.md`：Orca 持仓损益监控案例文档
- `coding_agent_orca_issues.md`：coding agent 写 Orca 代码时遇到的问题汇总

这些资料用于确认 API、参数、调用结构和常见错误修复方式。

## 6. 示例脚本

建议放入 `examples/` 目录的 `.dos` 示例脚本包括：

| 文件 | 覆盖能力 |
|---|---|
| `trade_anomaly_monitor.dos` | `map` + `timeSeriesEngine` + 异常窗口输出 |
| `net_buy_amount_monitor.dos` | 条件聚合 + 窗口告警 |
| `price_deviation_ma5_alert.dos` | `reactiveStateEngine` + 状态告警 |
| `order_trade_slippage_monitor.dos` | 多输入流 join + 滑点统计 |
| `trade_aggressiveness_monitor.dos` | `asofJoinEngine` + 盘口快照关联 + 聚合后占比计算 |
| `industry_amount_rank.dos` | `lookupJoinEngine` + `crossSectionalEngine` |
| `abnormal_spread_alert.dos` | 连续状态异常告警 |
| `market_overview_timer.dos` | 状态维护 + `timerEngine` |

这些脚本用于给 coding agent 提供可参考的代码组织方式，但生成新需求时不应机械照抄。

## 7. 常见问题规则

本 skill 特别关注以下高频问题：

- 不要使用不存在的 `existsStreamGraph`
- 清理旧图优先使用 `try { dropStreamGraph(name, true) } catch(ex) {}`
- `catch` 必须声明异常变量，例如 `catch(ex) {}`
- 不要写 JavaScript 风格的 `function(t) { ... }`
- `map` 中不要直接引用外部字典或外部可变变量
- `count()` 必须指定参数，例如 `count(TradeID)`
- “成交关联最近盘口快照”这类按事件时间就近匹配的需求，优先使用 `asofJoinEngine` / `snapshotJoinEngine`，不要误用 `lookupJoinEngine`
- 比值、占比类指标应先聚合分子分母，再在聚合后的 `map` 中计算
- 链式调用拆成多行时不要让新行以 `.` 开头，优先用中间变量逐步承接
- source schema 必须和 mock 数据列数、列顺序、类型一致
- `timeSeriesEngine` 的 mock 数据必须跨越窗口边界
- `reactiveStateEngine` 中不要随意使用未确认支持的序列敏感函数
- `crossSectionalEngine` 需要显式输出希望保留的分组列
- 查询结果表前不要想当然使用 `time` 列，应先查看真实 schema

## 8. 使用示例

用户请求示例：

```text
请用 DolphinDB Orca DStream API 写一个完整可运行脚本，实现“每 30 秒成交额突增监控”。
输入流表包含 SecurityID、TradeTime、Price、Volume。
每只股票每 30 秒统计 totalAmount、tradeCount、avgPrice，
只输出 totalAmount > 5000000 的窗口结果。
请包含 mock 数据和结果查询。
```

coding agent 应输出完整 `.dos` 脚本，而不是只输出：

```text
source -> timeSeriesEngine -> sink
```

## 9. 生成前自检

生成最终脚本前，coding agent 至少检查：

- 是否使用 `createStreamGraph`
- 是否使用 DStream API，而不是普通 SQL 替代
- 是否包含 `submit()`
- 是否包含 source schema
- source schema 和 mock 数据是否一致
- mock 数据是否能触发输出
- timeColumn 是否存在且为时间类型
- keyColumn 是否存在
- metrics 中引用的字段是否存在
- 如果是成交关联盘口快照，是否使用了具备 as-of 语义的 join 引擎
- 如果计算占比，是否在聚合后计算而不是在聚合前错误求和
- `count` 是否带参数
- 是否清理旧流图
- 是否写入 `appendOrcaStreamTable`
- 是否查询结果表
- 是否避免照搬官方示例

## 10. 输出要求

默认输出应包括：

1. 流图结构说明
2. 完整 DolphinDB `.dos` 脚本
3. mock 数据触发逻辑说明
4. 结果查询方式
5. 调试和生产环境注意事项

---

## 11. v1.2.0 新增内容

本版本新增 5 个由 DolphinDB 官方复杂流计算案例转写而来的 Orca DStream API 示例：

| 示例脚本 | 来源业务 | 主要测试点 |
|---|---|---|
| `examples/multi_source_asof_join_trade_cost.dos` | 多数据源流式实时关联处理：Asof Join 计算交易成本 | as-of join、右流写入顺序、delayedTime、查询路径 |
| `examples/future_position_indicator.dos` | 商品期货持仓指标实时计算 | 持仓流 + 行情流 asof 关联、指标计算、mock schema 对齐 |
| `examples/l2_delayed_trade_factor.dos` | Level-2 延时成交订单因子 | left semi join、状态函数、时间序列级联 |
| `examples/hf_money_flow_factor.dos` | 高频资金净流入比例因子 | timeSeriesEngine、buffer、fork、多窗口对齐 |
| `examples/avg_press_factor.dos` | 移动平均买卖压力因子 | reactiveStateEngine、标量 helper、mavg |

同时新增参考文档：

```text
references/orca/orca_conversion_cases.md
```

用于记录传统 `streamTable + subscribeTable + createXxxEngine` 案例改写为 Orca DStream API 时的稳定规则和调试经验。

