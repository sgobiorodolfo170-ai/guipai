# CSMAR 历史数据导入工具（DolphinX 版）

将 CSMAR（国泰安）高频历史行情数据文件自动导入 DolphinDB 分布式数据库。本工具运行于 **DolphinDB Web 平台**，全部操作通过 `.dos` 脚本在服务端完成。

## 提示词示例

```
帮我把 ../../data/csmar/ 下的CSMAR数据导入数据库。要导入的数据类型是全部五种数据，导入起始日期为20260429，结束日期是20260429，使用默认数据库名称。
```

---

## 数据流程

```mermaid
flowchart LR
    A[CSV/ZIP 数据文件] --> B[解压 & 解析]
    B --> C[DolphinDB 分布式库表]
```

支持五种数据类型：**快照（snapshot）**、**委托（entrust）**、**成交（trade）**、**TICK合并（tick）**、**委托队列（orderqueue）**。

---

## 快速开始

整个导入流程由 AI 助手在 DolphinDB Web 平台中自动完成，共 5 个步骤：

| 步骤 | 说明 |
| --- | --- |
| **步骤 1** | 环境检查与前置准备 — 调用 `check-env` 技能完成 zip 插件检查和 easy_csmar 模块上传 |
| **步骤 2** | 收集服务器机器信息，计算推荐并行度 |
| **步骤 3** | 填写数据导入参数（文件路径、数据类型、日期范围、数据库名称） |
| **步骤 4** | 确认参数无误 |
| **步骤 5** | 执行导入脚本，任务提交到后台运行 |

---

## 数据导入参数说明

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| **文件路径** | CSV 或 ZIP 文件所在目录的绝对路径 | `/hdd/hdd4/csmar/` |
| **数据类型** | snapshot（快照）/ entrust（委托）/ trade（成交）/ tick（TICK合并）/ orderqueue（委托队列） | `snapshot` |
| **起始日期** | 导入起始日期，格式 YYYYMMDD | `20260429` |
| **结束日期** | 导入结束日期，格式 YYYYMMDD | `20260429` |
| **数据库名称** | DolphinDB 数据库路径 | `dfs://level2_stock_db` |

> 表名固定为 `snapshot`、`entrust`、`trade`、`tick`、`orderqueue`，无需用户填写。

---

## 文件结构

```
├── README.md                                     ← 本文件
├── SKILL.md                                      ← AI 助手执行入口
└── scripts/
    ├── DolphinDBModules/
    │   └── easy_csmar/                            ← easy_csmar 模块源文件（14 个）
    │       ├── easy_csmar.dos                    ← 模块信息
    │       ├── utils.dos                         ← 工具函数
    │       ├── stock/                            ← 股票数据导入
    │       │   ├── create_stock_db.dos           ← 数据库创建
    │       │   ├── create_stock_tb.dos           ← 表创建
    │       │   ├── load_stock_data.dos           ← 批量导入主逻辑
    │       │   ├── stock_csv_schema/             ← CSV 表结构定义
    │       │   │   ├── entrust_csv_schema.dos
    │       │   │   ├── orderqueue_csv_schema.dos
    │       │   │   ├── snapshot_csv_schema.dos
    │       │   │   └── trade_csv_schema.dos
    │       │   └── stock_load_data/              ← 单日数据加载
    │       │       ├── load_one_day_entrust.dos
    │       │       ├── load_one_day_orderqueue.dos
    │       │       ├── load_one_day_snapshot.dos
    │       │       ├── load_one_day_tick.dos
    │       │       └── load_one_day_trade.dos
    ├── import_data.dos                           ← 批量导入脚本
    └── machine_info_collection.dos               ← 机器信息收集 + 推荐并行度
```

---

## 任务进度查询

导入任务提交到后台后，可通过以下方式查询进度：

1. **询问 AI 助手**：告知 AI 助手需要查询任务进度，助手将自动在 DolphinDB 中查询并返回结果
2. **返回信息包括**：
   - 正常运行：已处理的数据量、并行任务完成情况
   - 运行报错：错误原因及排查方向（文件路径、数据格式、磁盘空间、权限等）

---

## 注意事项

- 必须在 **DolphinDB Web 平台** 中以已登录用户身份操作
- 文件目录需对 DolphinDB 服务进程有读取权限
- 日期格式必须为 8 位数字 `YYYYMMDD`
- 首次使用前需执行 `check-env` 技能完成 zip 插件安装和 easy_csmar 模块上传
