# 通联历史数据导入工具（DolphinX 版）

将通联（DataYes）高频历史行情数据文件自动导入 DolphinDB 分布式数据库。本工具运行于 **DolphinDB Web 平台**，全部操作通过 `.dos` 脚本在服务端完成。

## 提示词示例

```
帮我把 ../../data/datayes 下的通联数据导入数据库。要导入的数据类型是全部的五种数据，导入起始日期为20150101，结束日期是20231127。
```

---

## 数据流程

```mermaid
flowchart LR
    A[CSV/ZIP 数据文件] --> B[解压 & 解析]
    B --> C[DolphinDB 分布式库表]
```

支持五种数据类型：**快照（tl_snapshot）**、**成交（tl_trade）**、**委托（tl_entrust）**、**TICK合并（tl_tick）**、**委托队列（tl_order_queue）**，可选择单个或多个导入。

---

## 快速开始

整个导入流程由 AI 助手在 DolphinDB Web 平台中自动完成，共 5 个步骤：

| 步骤 | 说明 |
| --- | --- |
| **步骤 1** | 环境检查与前置准备 — 调用 `check-env` 技能完成 zip 插件检查和 easy_datayes 模块上传 |
| **步骤 2** | 收集服务器机器信息，计算推荐并行度 |
| **步骤 3** | 填写数据导入参数（文件路径、数据类型、日期范围等） |
| **步骤 4** | 确认参数无误 |
| **步骤 5** | 执行导入脚本，任务提交到后台运行 |

---

## 数据导入参数说明

| 参数 | 说明 | 示例 |
| --- | --- | --- |
| **文件路径** | CSV 或 ZIP 文件所在目录的绝对路径 | `/hdd/hdd1/feb2023_csv` |
| **数据类型** | tl_snapshot（快照）/ tl_trade（成交）/ tl_entrust（委托）/ tl_tick（TICK合并）/ tl_order_queue（委托队列） | `tl_snapshot` |
| **起始日期** | 导入起始日期，DATE 类型 | `2023.02.01` |
| **结束日期** | 导入结束日期，DATE 类型 | `2023.02.01` |
| **数据库名称** | DolphinDB 数据库路径 | `dfs://TL_Level2` |
| **数据表名称** | 各数据类型对应的表名映射（设为 NULL 则自动命名） | `tl_snapshot=snapshot;tl_trade=trade` |

---

## 文件结构

```
├── README.md                                     ← 本文件
├── SKILL.md                                      ← AI 助手执行入口
└── scripts/
    ├── DolphinDBModules/
    │   └── easy_datayes/                          ← easy_datayes 模块源文件（22 个）
    │       ├── loadTLData.dos                    ← 主模块入口
    │       ├── utils.dos                         ← 工具函数
    │       ├── setconfig.dos                     ← 配置文件
    │       ├── createDbAndTb/                    ← 数据库/表创建
    │       ├── loadData/                         ← 数据加载
    │       └── tbSchema/                         ← 表结构定义
    ├── import_data.dos                           ← 批量导入脚本
    └── machine_info_collection.dos               ← 机器信息收集 + 推荐并行度
```

---

## 任务进度查询

导入任务提交到后台后，可通过以下方式查询进度：

1. **询问 AI 助手**：告知 AI 助手需要查询任务进度，助手将自动在 DolphinDB 中查询并返回结果
2. **返回信息包括**：
   - 正常运行：已处理的数据量、并行任务完成情况
   - 运行报错：错误原因及排查方向（文件路径、数据格式、磁盘空间、权限等）

---

## 注意事项

- 必须在 **DolphinDB Web 平台** 中以已登录用户身份操作
- 文件目录需对 DolphinDB 服务进程有读取权限
- 日期格式必须为 DATE 类型 `2023.02.01`
- 首次使用前需执行 `check-env` 技能完成 zip 插件安装和 easy_datayes 模块上传
