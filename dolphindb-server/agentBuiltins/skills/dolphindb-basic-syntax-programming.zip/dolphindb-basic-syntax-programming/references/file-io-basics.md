# File I/O Basics

Read this file when DolphinScript lists, opens, reads, writes, or exports Server-side files. Use the database/import reference for `loadText`, `loadTextEx`, and persistent table loading.

## Server-Side Paths And Permissions

File functions run in the DolphinDB Server process:

- Paths are resolved on the Server node executing the script, not on the Web browser or API client.
- In a cluster, the same path can refer to different storage on different nodes.
- `file` and `files` require an authenticated user and are subject to Server and operating-system permissions.
- Inspect with `files(directory)` before reading when the path is not already verified.
- Do not invent a path or assume a client upload is Server-visible.

## Open Modes

```dos
fin = file(inputPath, "r")
fout = file(outputPath, "a")
```

Modes:

- `r`: read from the start; the file must exist.
- `r+`: read/write from the start.
- `w` / `w+`: create or truncate the file.
- `a` / `a+`: create if needed and append from the end.

Opening an existing file with `w` or `w+` destroys its previous content. Use these modes only when replacement is explicitly intended.

File handles are normally closed when their function scope ends, but explicitly call `close()` for long-lived scripts, loops, error-sensitive workflows, or when later code must immediately reuse the file:

```dos
fin.close()
```

## Text Files

Use bulk operations for multiple lines:

```dos
fout = file(outputPath, "w")
written = fout.writeLines(["first", "second"])
fout.close()

fin = file(outputPath, "r")
lines = fin.readLines(1024)
fin.close()
```

Rules:

- `writeLine` and `writeLines` append the platform-appropriate line ending; do not add another line ending unless it is part of the content.
- `readLine` omits the line ending and returns a VOID value at end of file. Test EOF with `isVoid`.
- `readLines(n)` returns at most `n` lines. Fewer than `n` lines means EOF was reached.
- Prefer `readLines` / `writeLines` over a line-at-a-time loop for ordinary bulk text.

## Binary And Object Files

Choose one format deliberately:

- `readBytes` / `writeBytes` operate on raw CHAR byte buffers. `readBytes` requires the exact requested byte count and raises at EOF.
- `read!` / `write` reuse typed buffers and require agreement on data type, count, and byte order.
- `readObject` / `writeObject` serialize DolphinDB objects such as vectors, matrices, dictionaries, and tables.

When typed binary data crosses machines, specify and verify endianness. Do not use object serialization as an interchange format with an unrelated system unless compatibility is documented.

## Tables And Export

- `saveText` exports a table, vector, matrix, or SQL metacode result as Server-side CSV text. It is readable but larger and slower than binary storage.
- `saveTable` stores a table in an unpartitioned local disk database; it is not the write path for DFS partitioned tables.
- For DFS partitioned tables, create the target table and write with `append!` or `tableInsert` according to the database reference.

Before exporting, confirm the exact Server node, target path, overwrite/append behavior, delimiter, header, and encoding requirements.
