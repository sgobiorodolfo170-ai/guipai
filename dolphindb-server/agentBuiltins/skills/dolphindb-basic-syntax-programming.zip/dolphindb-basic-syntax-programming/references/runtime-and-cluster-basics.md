# Runtime And Cluster Basics

Read this file before generating DolphinScript whose behavior depends on deployment mode, node role, DFS placement, RPC, cluster-wide state, or stream-data high availability.

## Establish The Current Environment First

Use runtime facts already supplied for the current request. If the deployment mode or node role is absent, stale, or contradictory, run a read-only probe before choosing an execution path:

```dos
nodeType = getNodeType()
nodeAlias = getNodeAlias()
table(nodeAlias as nodeAlias, nodeType as nodeType)
```

`getNodeType()` returns:

| Value | Current node |
|---:|---|
| 0 | data node |
| 1 | agent |
| 2 | controller |
| 3 | single-node mode |
| 4 | compute node |

Rules:

- Treat the current execution node as the environment for the current operation. Do not assume a node mentioned earlier in the conversation is still current.
- Do not infer node role from the accessed port, host, ability to query a DFS table, or ability to submit database DDL.
- Use `getNodeAlias()` for the local alias. Use `getControllerAlias()` only when a cluster operation actually needs the controller.
- Keep environment probes read-only. Do not restart nodes or change configuration merely to identify the topology.

## Deployment Modes Are Distinct

DolphinDB has single-instance mode and cluster mode.

- Single-instance mode has one single-mode node and no controller, agent, or compute node.
- A single-server cluster is still cluster mode. It may run multiple cluster roles on one physical server and must not be treated as single-instance mode.
- A cluster may span one or multiple physical servers.
- A cluster may be ordinary or highly available. Merely being in cluster mode does not prove that any high-availability feature is enabled.

## Cluster Node Roles

| Role | Basic responsibility |
|---|---|
| controller | Monitors node heartbeats and state; manages DFS metadata and transactions. |
| agent | Starts and stops data and compute nodes when instructed by the controller; one agent runs on each physical server. |
| data node | Stores data and also performs queries and computation. |
| compute node | Performs query, stream-computing, distributed-join, and machine-learning workloads without persistently storing data. |

Important consequences:

- Prefer data or compute nodes for ordinary workload scripts. Do not assume controller or agent nodes are interchangeable execution targets.
- A compute node can execute database and table creation statements; the database is created and stored on data nodes.
- A compute node can load DFS tables for computation. Successful `loadTable` therefore does not prove that the current node is a data node.
- Before using RPC or cluster-wide functions, identify which node owns the requested state and whether the function must run locally on that node.

## High Availability Is Feature-Specific

Keep these concepts separate:

- Data high availability uses replicas.
- Metadata high availability uses multiple controllers and Raft.
- Client high availability uses multiple sites and failover behavior.
- Stream-data high availability is a separately configured Raft-based feature.

Do not conclude that stream-data high availability is enabled merely because the environment is a cluster or because another high-availability mechanism exists.

## Stream-Data High Availability And Raft

Stream-data high availability is supported in cluster mode, not single-node mode. It requires explicit configuration, including:

- `streamingHAMode=raft`
- `streamingRaftGroups` with configured data-node or compute-node aliases
- at least three member nodes per group
- a group ID greater than or equal to 2
- a distinct `persistenceDir` for each cluster node
- a distinct `streamingHALogDir` for each node when multiple nodes share a physical server

Each Raft group elects one Leader; the other members are Followers. A high-availability stream table belongs to a configured group. A normal stream table has no Raft group and is not automatically highly available.

Before creating or using a high-availability stream table:

1. Confirm that the current deployment is cluster mode and that the current node is a data or compute node suitable for the operation.
2. Verify actual Raft-group configuration; never invent a group ID from an example.
3. Check local membership with `getStreamingRaftGroups()`.
4. Remember that `getStreamingRaftGroups()` reports groups for the current node only. An empty local result does not by itself prove that the whole cluster has no stream Raft group.
5. When a cluster-wide inventory is necessary, collect and deduplicate results from data and compute nodes:

```dos
select id, sites from pnodeRun(getStreamingRaftGroups) where isDuplicated([id, sites], FIRST) = false
```

6. Call `getStreamingLeader(groupId)` on a member of that group. If the current node is not a member, discover a member first and use RPC only after confirming the target.

For a high-availability subscription, subscribe to a group member and enable reconnect behavior. Do not apply the high-availability subscription path to a normal stream table.

## Decision Checklist

Before returning topology-sensitive code, verify:

- Is this single-instance mode or cluster mode?
- What is the current node type and alias?
- Does the operation belong on the current node, controller, a data node, a compute node, or a specific Raft-group member?
- Is the requested high-availability feature actually configured, or merely assumed from the word “cluster”?
- Does a local empty result mean “not configured globally,” or only “not present on this node”?
- Are node aliases, group IDs, paths, and remote targets discovered from the environment rather than invented?
