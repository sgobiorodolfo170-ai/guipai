# Variables, Scope, And Errors

Read this file when code defines or releases names, crosses sessions, resolves SQL names, returns from functions, or catches and raises exceptions.

## Names And Lifetime

Variable names must start with a letter and then contain letters, digits, or `_`. Do not use data types, data forms, control-flow words, SQL words, or other reserved names as variables.

Variables can be rebound to values of another type:

```dos
x = 1 2 3
x = 3.5 4.5
```

Use object names, not object values, with `defined` and `undef`:

```dos
defined(`x, VAR)
undef(`x, VAR)
defined(`sharedT, SHARED)
defined(`f, DEF)
```

`undef` takes effect at runtime. A later statement in the same submitted script can require a `go` boundary so the parser sees the changed name registry.

## Session And Shared Objects

Ordinary objects are local to the current session. Another session cannot see a local table merely because it connects to the same Server.

`share table as name` exposes a supported table to other sessions on the current node. It does not make the object cluster-global. Shared engines are retrieved according to the engine API rather than treated as ordinary local variables.

Before reusing or replacing shared state:

- Check with `defined(name, SHARED)`.
- Confirm the current node; the same shared name on another node is a different runtime object.
- Avoid unconditionally replacing a shared table that other sessions may be using.

## Column And Variable Name Resolution

In SQL, ambiguous names resolve in this order: table column, variable, function. SQL column matching is case-insensitive. Therefore, never give an external filter value the same name as a table column:

```dos
// Unsafe: date may resolve to column Date, making Date = Date.
date = 2024.01.01
select * from t where Date = date

// Safe.
targetDate = 2024.01.01
select * from t where Date = targetDate
```

If a function name conflicts with a column or variable, qualify the function with `&name`, `::name`, or its module name where supported. Rename variables to resolve column/variable conflicts; do not depend on capitalization.

Outside SQL, `t.col` is a read-only column reference. Use table indexing or an update API for mutation:

```dos
v = t.qty
v[0] += 1          // does not update t.qty
t[`qty] = v        // explicit write-back
```

## Return

`return [expression]` terminates the current function and returns its result:

```dos
def normalizeQty(qty) {
    if(isNull(qty)) {
        return 0
    }
    return max(qty, 0)
}
```

Use explicit `return` in generated multi-statement functions when callers depend on the result. Do not hide required output in `print`, `timer`, or an assignment that the caller cannot access.

## Throw And Catch

Use `throw` for an invalid caller-visible condition:

```dos
def requirePositive(x) {
    if(isNull(x) || x <= 0) {
        throw "x must be non-null and positive"
    }
    return x
}
```

Catch only when the script can recover, add useful context, or return a deliberate error object:

```dos
try {
    result = riskyOperation()
} catch(ex) {
    throw "riskyOperation failed: " + string(ex)
}
```

Rules:

- An exception stops the current path until a matching `catch` handles it.
- `catch(ex)` receives an exception object whose printable representation can include an error category and message. Use `string(ex)` for human-readable reporting; do not parse the displayed pair format as a stable API.
- Throwing `string(ex)` creates a user exception and can discard the original system category. Preserve or log the original exception when that distinction is operationally important.
- Do not catch an error only to print it and then return an apparently successful result.
- Keep the `try` block narrow so setup errors and the intended recoverable operation are not conflated.
