# Type Conversion And Precision

Read this file when code converts types, constructs typed nulls, compares floating-point values, inserts values into a typed schema, or uses DECIMAL.

## Inspect Before Converting

Use `typestr`, `form`, and table schema inspection when the source type or result shape is not already known:

```dos
typestr(x)
form(x)
schema(t).colDefs
```

Do not assume that an arithmetic expression, aggregate, import, or conditional expression preserves its input type. Inspect the result or check the function documentation when the concrete result type matters.

## Explicit Conversion

Use a type constructor or `cast` / `$` for explicit conversion:

```dos
qty = int("12")
price = double("12.5")
sym = `IBM`MSFT$SYMBOL
x = 1..4$DOUBLE
m = 1..6$2:3
```

Rules:

- `X$TYPE` changes data type; `X$rows:cols` reshapes a vector or matrix.
- Type constructors accept only semantically compatible inputs. Do not treat conversion as input validation.
- `short`, `int`, and `long` round floating-point input to an integer. Conversion from a numeric string stops at the first non-numeric character according to the documented constructor behavior.
- Out-of-range conversion behavior differs by target type and Server version and can produce NULL, wrap, clamp, or raise an error. Check bounds before conversion and validate the result with `isNull` when overflow matters.
- Convert values explicitly before inserting into a typed table when the source schema does not already match the target schema.

## Typed NULL

`NULL` is VOID. Use a typed constructor when a vector or table column needs a concrete type:

```dos
missingQty = int()
missingPrice = double()
missingDate = date()
missingName = string()

qty = take(int(), 5)
t = table(5:0, `id`price, [INT, DOUBLE])
```

Rules:

- A VOID value cannot be used to create an ordinary typed vector or column.
- `select NULL as col from t` creates a VOID column that cannot later accept an unrelated typed value.
- Prefer `string(NULL)`, `int(NULL)`, or another typed null when a SQL result column will later be updated.
- Use `isNull` to check typed and untyped null values; do not infer nullness from printed output.

## Floating-Point Comparisons

Binary floating-point values can print as expected while differing at lower bits. Do not use exact `==` for tolerance-based checks:

```dos
eqFloat(actual, expected, 9)
```

Use exact `==` only when exact equality is the intended contract. Use `eqFloat` with an explicit precision for FLOAT or DOUBLE verification.

## DECIMAL

Create DECIMAL with an explicit scale:

```dos
price = decimal64("123.4500", 4)
amount = decimal128("999999.99", 2)
```

Rules:

- Prefer a STRING input when the decimal text must be represented exactly. Converting a FLOAT or DOUBLE can carry its binary approximation into the DECIMAL value.
- Every element in a typed DECIMAL vector must have the same DECIMAL type and scale. Mixed scales can produce an ANY vector instead of a fast typed vector.
- Scale means retained fractional digits. Multiplication accumulates scale and can overflow even when the displayed numeric magnitude looks reasonable.
- Newer Server versions may widen DECIMAL arithmetic to a larger DECIMAL type when one is available, but DECIMAL128 can still overflow. Do not rely on widening as a bounds check.
- Aggregates do not all preserve DECIMAL. For example, `sum` can widen while many statistical functions return DOUBLE. Check the function documentation or `typestr(result)` when downstream schema depends on the result type.
- STRING/SYMBOL-to-DECIMAL rounding and other details have changed between Server versions. Avoid encoding version-sensitive expected values without checking the target Server version.

For financial values, choose the DECIMAL type and scale from the required integer range and fractional precision rather than using the largest scale by default.
