# Operators And Expressions

Read this file when an expression mixes function-style operators, arithmetic, comparison, logical operators, sequences, pairs, or conditional expressions.

## Make Evaluation Order Explicit

Operators at the same precedence level evaluate from left to right. Parenthesize mixed expressions when their grouping affects correctness, especially in generated code.

DolphinDB unary function-style syntax consumes the expression to its right more broadly than many languages:

```dos
sum 1 2 3 == 6       // sum(1 2 3 == 6)
(sum(1 2 3)) == 6    // compare the sum with 6

sin x + cos x        // sin(x + cos(x))
sin(x) + cos(x)      // add two function results
```

`neg` (`-`) and `not` (`!`) follow their configured operator precedence instead of the general unary function-style rule. Still use parentheses when they are mixed with ranges or arithmetic:

```dos
(-n)..n
!(x > limit)
```

User-defined functions used as infix operators have multiplication/division precedence. Prefer ordinary call syntax in first-draft code unless infix form materially improves readability.

## Sequence, Pair, And Division

```dos
1..5       // inclusive sequence: 1,2,3,4,5
1:5        // pair; upper endpoint is excluded in indexing/loops
5 / 2      // integer division: 2
5 \ 2      // ratio division: 2.5
```

Do not infer a result type only from the operator token. Operand types affect division and other arithmetic; inspect or convert operands when the output type is part of the contract.

## Elementwise Shape

Many DolphinDB operators accept scalars, vectors, and matrices and apply elementwise. When both operands are vectors or matrices, their lengths or dimensions must usually agree.

Do not assume NumPy-style multidimensional broadcasting. If operands have different forms or sizes, check the specific operator/function documentation and verify the result shape with `form`, `size`, or `shape`.

## Comparison And Logic

DolphinDB supports chained comparison in ordinary expressions:

```dos
1 < x <= 10
```

Chained comparison also works elementwise for compatible vectors and matrices. However, do not use chained conditions in distributed SQL merely for compactness: partition pruning can require explicit non-chained predicates.

Use parentheses around compound logical conditions:

```dos
(qty > 0) && (price > 0)
(isNull(x)) || (isNull(y))
```

This avoids the unary function parsing trap in expressions such as `isNull x || isNull y`.

## Ternary Operator

Syntax:

```dos
condition ? trueClause : falseClause
```

Rules:

- `condition` must be a non-NULL BOOL scalar or vector.
- Parenthesize a condition that is an expression: `(qty > 0) ? qty : 0`.
- For a BOOL scalar, only the selected branch is executed.
- For a BOOL vector, the expression behaves like `iif`; both branches may be executed. Do not place writes, destructive calls, or branch-specific expressions that are invalid for part of the data in either branch.
- Branch result types and forms determine the result. Inspect or explicitly cast the branches when a target schema requires one concrete type.

For multi-statement or side-effecting alternatives, use `if/else` rather than a ternary expression.
