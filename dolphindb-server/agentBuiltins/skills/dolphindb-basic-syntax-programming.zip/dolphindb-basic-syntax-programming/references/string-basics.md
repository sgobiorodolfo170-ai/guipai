# String Basics

Read this file when code constructs, converts, escapes, combines, searches, splits, or replaces STRING, SYMBOL, or CHAR values.

## STRING, SYMBOL, And CHAR

```dos
name = "DolphinDB"       // STRING
code = `IBM               // STRING
letter = 'A'              // CHAR
symbols = `IBM`MSFT$SYMBOL
```

Rules:

- Single quotes around one character create CHAR. Double quotes and backticks create STRING.
- Backticks are for simple symbol-like text and cannot contain spaces; use quoted strings for general text and paths.
- A backtick sequence such as `` `IBM`MSFT `` is a STRING vector until explicitly converted to SYMBOL.
- SYMBOL is intended for repeated categorical text. Do not cast arbitrary free-form text to SYMBOL merely because it is a string column.
- DolphinDB strings use UTF-8. Use encoding-conversion functions only when an external source has a known different encoding.

## Escaping

Quoted strings support common escapes:

```dos
line = "first\nsecond"
tabbed = "a\tb"
pathText = "A\\B"
quoted = "He said \"hello\""
```

Use the other quote style when it avoids unnecessary escaping:

```dos
text1 = "it's ready"
text2 = 'say "ready"'
```

## Empty And NULL Strings

The empty STRING is DolphinDB's STRING null representation. Do not design logic that requires an empty STRING and a null STRING to be distinct values.

```dos
missingText = string()
isNull(missingText)
```

Use `isNull` for missing-value checks. Do not rely on display output, `strlen`, or whitespace tests to distinguish missing data.

## Convert And Format

Use `string(x)` for a general textual representation and `format(x, pattern)` when numeric or temporal formatting is part of the output contract:

```dos
raw = string(108.5)
priceText = format(123.45, "0.00")
dateText = format(2024.01.31, "yyyy-MM-dd")
```

Formatting returns text; it does not change the stored numeric or temporal value.

## Combine And Split

Use `+` for direct string concatenation and `concat` when joining a string vector with a delimiter:

```dos
message = "id=" + string(42)
csv = concat(`IBM`MSFT`GOOG, ",")
parts = split("IBM|MSFT|GOOG", "|")
```

Rules:

- `concat` converts NULL arguments to empty strings and has different scalar/vector behavior; check input form before using it as a generic join.
- `split` without a delimiter splits a scalar STRING into CHAR values.
- Splitting a STRING vector returns a columnar tuple. Use `result[i]` for a column and `result.row(i)` for a row.

## Search And Replace

Prefer literal operations unless regular expressions are required:

```dos
pos = strpos("abcdef", "cd")       // 2; -1 means not found
clean = strReplace("a-b-c", "-", "_")
leftPart = substr("abcdef", 0, 3)
```

Use `like` / `ilike` for wildcard matching, `regexFind` for regex search, and `regexReplace` for regex replacement. Prefer `strpos` and `strReplace` for literal text because their intent is clearer and they avoid regex escaping mistakes.

String positions are zero-based. Use `charAt(text, index)` when a CHAR result is required.
